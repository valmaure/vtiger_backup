<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$languageStrings = array(
	'ITS4YouStyles' => 'Estilos 4 You',
	'SINGLE_ITS4YouStyles' => 'Estilo',
        'LBL_STYLES_LIST' => 'Estilos',
	'LBL_BLOCK_GENERAL_INFORMATION' => 'Información Básica',
	'LBL_CONTENT_INFORMATION' => 'Contenido del Estilo',
        'LBL_BLOCK_SYSTEM_INFORMATION' => 'Información del Sistema',
        'LBL_ADD_STYLE' => 'Agregar Estilo',
);
