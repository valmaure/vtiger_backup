<?php
/*********************************************************************************
 * The content of this file is subject to the Reset CP Password 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * *******************************************************************************/

$languageStrings = Array (
    "ITS4YouResetCPPassword" => "Reiniciar Clave PC",
    "LBL_RESET_EMAIL_CONFIRMATION" => "¿Quiere reiniciar la Clave de Acceso al Portal de Clientes?",
    "LBL_NO_CUSTOMER_PORTAL" => "Este cliente no tiene una cuenta del Portal de Clientes",
    "LBL_EMAIL_OK" => "La clave fué reiniciada y se le envió al email del contacto",
);

$jsLanguageStrings = array(
        
);